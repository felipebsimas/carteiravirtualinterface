<?php
session_start();
include('verificar_login.php');
include('conexao.php');



$sql = "SELECT * FROM gastos";
$resultado = mysqli_query($conexao, $sql);
$dados1 = mysqli_fetch_array($resultado);


?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<!-- CSS arquivo-->
<link rel="stylesheet" type="text/css" href="css1.css">
  <!-- CSS conexão bootstrap -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <!--    icones     -->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">


  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

   <script type="text/javascript">
 google.load("visualization", "1", {packages:["corechart"]});
 google.setOnLoadCallback(drawChart);
 function drawChart() {
 var data = google.visualization.arrayToDataTable([
 
 ['nome','valor'],
 <?php 
			$query = "SELECT * from gastos";
 
			 $exec = mysqli_query($conexao ,$query);
			 while($row = mysqli_fetch_array($exec)){
 
			 echo "['".$row['nome']."',". $row['valor']."],";
			 }
			 ?> 
 
 ]);
 
 var options = {
 title:  'Meus principais gastos',
  pieHole: 0,
          pieSliceTextStyle: {
            color: 'black',
          },
          legend: 'none'
 };
 var chart = new google.visualization.PieChart(document.getElementById("columnchart12"));
 chart.draw(data,options);
 }
	
    </script>
   
<body>
	<nav class="menu" style="width: 100%;">
  <h5 class="titulo" href="#" style="padding-top: 3px;font-size: 25px;">Carteira Virtual</h5>
  <h6 class="logout" style="margin:auto; position: relative; padding-bottom: 3px;">Olá, <?php echo $_SESSION['nome']; ?></h6>
      <a class="logout" href="inicial.html" style="color: white;">Sair</a>
</nav>

<!-- <div class="container-fluid" style="width: 300px; margin-left: 0px;"> -->
  <div class="row">
    <nav class="col-md-2 d-none d-md-block black sidebar" style="position: absolute; margin-right: 0px; height: 100%; ">
      <div class="sidebar-sticky">
          <li class="nav-item" style="padding-top: 10px;list-style-type: none;">
            <a href="painel.php" style="font-size: 20px; text-decoration: none; color: black; padding-left: 15px;">
              <span data-feather="home"></span>
              <i class="fa fa-align-justify"></i>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item" style="padding-top: 30px;list-style-type: none;">
              <a href="adicionar.php" style="font-size: 20px; text-decoration: none; color: black; padding-left: 15px;">
            <i class="fa fa-align-justify"></i>
              Painel
            </a>
          </li>
    </div>
</nav>
</div>
</div>



<div class="content" style="margin-left: 17%; margin-top: 1.5%;">
        <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-body" style="background-color: #BF382E;">
              	<img src="despesa.png" style="position: absolute; height: 30%; width: 30%;">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i class="nc-icon nc-globe text-warning"></i>
                    </div>
                  </div>

                  <?php 
                  $sql = "SELECT * FROM gastos ORDER BY id DESC";
					$resultado = mysqli_query($conexao, $sql);
						$dados1 = mysqli_fetch_array($resultado); ?>


                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <h5 class="card-category" style="color: white; margin-bottom: 20%">Última Despesa</h5>
                      <h5 class="card-title" style="color: white;"> R$ <?php echo $dados1['valor'] ?> </h5>
                        <p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                	<p style=" white-space: nowrap; font-size: 70%; text-align: center;">Seu último gasto
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-body" style="background-color: #40A853;">
              	<img src="receita.png" style="position: absolute; height: 30%; width: 30%;">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i class="nc-icon nc-money-coins text-success"></i>
                    </div>
                  </div>
				<?php
				$sql = "SELECT * FROM receita ORDER BY id_receita DESC LIMIT 1";
					$resultado = mysqli_query($conexao, $sql);
						$dados2 = mysqli_fetch_array($resultado);

?>
                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <h5 class="card-category" style="color: white; margin-top: 12%; padding: 0; margin: auto; margin-bottom: 20%;;">Última Receita</p>
                      <h5 class="card-title" style="color: white; margin-top:0;">R$ <?php echo $dados2['valor_receita'] ?> 
                        <p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
        <p style=" white-space: nowrap; font-size: 70%; text-align: center;">Sua última receita </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-body " style="background-color: #BF382E;">
              	<img src="despesamensal.png" style="position: absolute; height: 30%; width: 30%;">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i class="nc-icon nc-vector text-danger"></i>
                    </div>
                  </div>
                  <?php
				$sql = "SELECT sum(valor) as valor from gastos";
					$resultado = mysqli_query($conexao, $sql);
						$dados3 = mysqli_fetch_array($resultado);

					?>

                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <h5 class="card-category" style="color: white; margin-bottom: 20%">Despesas Total</h5>
                      <h5 class="card-title" style="color: white;">R$ <?php echo $dados3['valor'] ?>
                        <p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
       <p style=" white-space: nowrap; font-size: 70%; text-align: center;">Suas despesas totais
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats" style="margin-right: 1%;">
              <div class="card-body" style="background-color: #2AD49E">
              	<img src="despesamensal.png" style="position: absolute; height: 30%; width: 30%;">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i class="nc-icon nc-favourite-28 text-primary"></i>
                    </div>
                  </div>


                  <?php
				$sql = "SELECT (SELECT SUM(valor_receita) FROM receita) - (SELECT SUM(valor) FROM gastos) as valor";
					$resultado = mysqli_query($conexao, $sql);
						$dados4 = mysqli_fetch_array($resultado);

					?>

                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <h5 class="card-category" style="color: white; margin-bottom: 20%;">Saldo Total</h5>
                      <h5 class="card-title" style="color: white;">R$ <?php echo $dados4['valor'] ?>
                        <p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <p style=" white-space: nowrap; font-size: 70%; text-align: center;">Seus lucros totais
                </div>
              </div>
            </div>
          </div>
        </div>







<div style="margin-top: 2%; padding-right: 15px; height: 100%; width: 50%; float: left; margin-left: 0;">
	<table class="table">

    <tr>
      <th style="float: left;">Últimos gastos </th>

    </tr>
  
	<?php 
	$result_usuarios = "SELECT * FROM gastos ORDER BY id DESC LIMIT 5";
	$resultado_usuarios = mysqli_query ($conexao, $result_usuarios);
	while ($dado = mysqli_fetch_assoc($resultado_usuarios)){
	?>
  
    <tr>
      <td><?php echo $dado['nome'] ?></td>
      <td>R$ <?php echo $dado['valor'] ?></td>
      <td style="float: right;"><?php echo $dado['data_gastos'] ?> </td>
  <?php } ?>
    </tr>
  
</table>
</div>

<div style="margin-top: 2%; padding-left: 15px; height: 100%; width: 50%; float: right; margin-right: 0;">
	<table class="table">

    <tr >
      <th style="float: left;">Últimas receitas </th>

    </tr>
<?php 
	$result_usuarios = "SELECT * FROM receita ORDER BY id_receita DESC LIMIT 5";
	$resultado_usuarios = mysqli_query ($conexao, $result_usuarios);
	while ($dado = mysqli_fetch_assoc($resultado_usuarios)){

?>
    <tr>
      <td><?php echo $dado['nome_rec'] ?></td>
      <td style="padding-right: 50px;">R$ <?php echo $dado['valor_receita'] ?></td>
       <td><?php echo $dado['data_receita'] ?> </td>
  <?php } ?>
    </tr>

</table>
</div>
<div class="container-fluid" style="margin-top: 300px; width: 100%">
<div id="columnchart12" style="width: 100%; height: 500px; margin-left: 0;"></div>

	</div>

</body>
</html>
