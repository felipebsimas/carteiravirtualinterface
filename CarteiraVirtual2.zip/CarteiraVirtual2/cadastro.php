<?php
session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login CarteiraVirtual</title>
	<link rel="stylesheet" href="cadastrostyle.css">
</head>
<body>
		<?php 
		if (isset($_SESSION['status_cadastro'])):
		?>
		<div>
			<p>Cadastro concluido com sucesso! Clique <a href="login.php">aqui</a> para efetuar o login!</p>
		</div>
		<?php
		unset($_SESSION['status_cadastro']);
		endif;
		?>

		<?php
		if (isset($_SESSION['usuario_existe'])):
		?>
	<div>
		<p>Usuario já existente no sistema! Tente outro.</p>
	</div>

	<?php
	unset($_SESSION['usuario_existe']);
	endif;
	?>

	<style type="text/css">
			.box input[type="submit"]:hover{

	background: #2980b9;
	
}
		</style>

		<form class="box" action="cadastrar.php" method="POST">
			<img id="logo" src="logo3.png">
			<input type="text" name="nome" placeholder="Nome Completo">
			<input type="email" name="email" placeholder="Email">
			<input type="text" name="user" placeholder="Nome de Usuario">
			<input type="password" name="password" placeholder="Senha">
			<input type="submit" name="" value="Cadastrar" style="width: 300px;">
		</form>

</body>
</html>