<?php
session_start();

include('conexao.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$usuario = $_POST['user'];
$senha = $_POST['password'];


$sql = "SELECT COUNT(*) as total from usuario where usuario = $usuario";
$result = mysqli_query($conexao, $sql);
$row = mysqli_fetch_assoc($result);

if ($row['total'] == 1) {
	$_SESSION['usuario_existe'] = true;
	header('Location: cadastro.php');
	exit();
} 

$sql = "INSERT INTO usuario (usuario, senha, nome, email) VALUES ('$usuario', '$senha', '$nome', '$email')";

if ($conexao->query($sql) === true) {
	$_SESSION['status_cadastro'] = true;
	header('Location: cadastro.php');
	exit();
		
}

$conexao->close();
header('Location: cadastro.php');
exit;
?>
