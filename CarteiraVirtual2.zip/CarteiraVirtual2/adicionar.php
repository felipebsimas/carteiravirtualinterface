
<?php
session_start();
include('verificar_login.php');
include('conexao.php');
include('header2.php');



$sql = "SELECT * FROM gastos";
$resultado = mysqli_query($conexao, $sql);
$dados1 = mysqli_fetch_array($resultado);


?>

<nav class="menu" style="width: 100%; height: 57px;">
  <h5 class="titulo" href="#" style="padding-bottom: 20px; font-size: 25px; padding-left: 1px;">Carteira Virtual</h5>
  <h6 class="logout" style="font-size:1.10rem; padding-bottom: 16px;padding-right: 3px;">Olá, <?php echo $_SESSION['nome']; ?></h6>
 
    <li class="nav-item text-nowrap" style="list-style-type: none;">
      <a class="logout" href="logout.php" style="color: white;" >Sair</a>
    </li>
  
</nav>
<div style = "height: 900px; width: 175px;  position: absolute; background-color: black; padding-right: 5px;">
          <li class="nav-item" style="padding-top: 10px;list-style-type: none;" >
            <a href="painel.php" style="font-size: 20px; text-decoration: none; color: white; padding-left: 15px;">
              <span data-feather="home"></span>
              <i class="fa fa-align-justify"></i>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item" style="padding-top: 30px;list-style-type: none;">
            <a href="adicionar.php" style="font-size: 20px; text-decoration: none; color: white; padding-left: 15px">
            <i class="fa fa-align-justify"></i> Painel</a>
          </li>
    </div>

<div class="row" style="padding-right: 700px; padding-top: 20px; ">
	<div class="col s12 m6 push-m3">
		<h1 class="light"> <i class="small material-icons red">add</i> Novo Gasto</h1>
		<form action="create.php" method="POST">
			<div class="input-field col s12">
				<input type="text" name="nome" id="">
				<label for="nome">Nome do gasto</label>
			</div>

			<div class="input-field col s12">
				<input type="text" name="valor" id="">
				<label for="valor">Valor em R$</label>
			</div>
			<div class="input-field col s12">
				<input type="date" name="data" id="">
				<label for="data">Data da receita</label>
			</div>

			<button type="submit" name="btn-cadastrar" class="btn"> Cadastrar gasto </button>

		</form>
		
	</div>
</div>

<div class="row" style="padding-right: 700px; padding-top: 2px;">
	<div class="col s12 m6 push-m3">
		<h1 class="light"> <i class="small material-icons green">add</i> Nova Receita</h1>
		<form action="add.php" method="POST">
			<div class="input-field col s12">
				<input type="text" name="nome" id="">
				<label for="nome">Origem da receita</label>
			</div>

			<div class="input-field col s12">
				<input type="text" name="valor" id="">
				<label for="valor">Valor em R$</label>
			</div>
			<div class="input-field col s12">
				<input type="date" name="data" id="">
				<label for="data">Data da receita</label>
			</div>

			<button type="submit" name="btn-cadastrar" class="btn"> Cadastrar receita </button>

		</form>
		
	</div>
</div>

<div class="row" style="padding-right: 700px; padding-top: 2px;">
	<div class="col s12 m6 push-m3">
		<h1 class="light"> <i class="small material-icons orange">autorenew</i> Virou o mês?</h1>
		</br>
		<span class="light">Deleta todos os gastos e receitas adicionados ao sistema!</span>
	</br>
	</br>
	
		<form action="del.php" method="POST">
			<input type="hidden" name="id" value="dell">
			<button type="submit" name="btn-deletar" value="deletar" class="btn" style="float: left;">Atualizar Gastos</button>
		</form>
			<form action="delrec.php" method="POST" style="padding-right: 420px;">
			<input type="hidden" name="id_rec" value="dellrec">
			<button type="submit" name="btn-deletarreceita" value="delrec" class="btn" style="float: right;">Atualizar Receitas</button>

		</form>
	</div>
</div>

 
 <?php include('footer.php'); ?>
