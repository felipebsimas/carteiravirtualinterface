<?php
// Sessão
session_start();
// Conexão
require_once 'conexao.php';
// Clear
function clear($input) {
	global $conexao;
	// sql
	$var = mysqli_escape_string($conexao, $input);
	// xss
	$var = htmlspecialchars($var);
	return $var;

}



	

if(isset($_POST['btn-cadastrar'])):
	$nome = ($_POST['nome']);
	$valor = ($_POST['valor']);
	$data_gastos = ($_POST['data']);


	$sql = "INSERT INTO gastos (nome, valor, data_gastos) VALUES ('$nome', '$valor', '$data_gastos')";

	if(mysqli_query($conexao, $sql)):
		$_SESSION['mensagem'] = "Sucesso!";
		header('Location: adicionar.php');
	else:
		$_SESSION['mensagem'] = "Erro desconhecido!";
		header('Location: adicionar.php');
	endif;
endif;
?>
