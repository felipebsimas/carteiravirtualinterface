<?php
session_start();
include('conexao.php');

if(empty($_POST['usuario']) || empty($_POST['senha'])) {
	header('Location: login.php');
	exit();
}

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];


$query = "SELECT nome FROM `usuario` WHERE usuario = '{$usuario}' and senha = '{$senha}'";

$result = mysqli_query($conexao, $query);

$row = mysqli_num_rows($result);

if ($row == 1){
	$usuario_bd = mysqli_fetch_assoc($result);
	$_SESSION['nome'] = $usuario_bd['nome'];
	header('Location: painel.php');
	exit();


}else{
	$_SESSION['nao_autenticado'] = true;
	header('Location: login.php');
	exit();
}
?>

