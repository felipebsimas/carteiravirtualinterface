<?php
// Sessão
session_start();
// Conexão
require_once 'conexao.php';

if(isset($_POST['btn-deletarreceita'])):


	
	$sql = "DELETE FROM receita";
	

	if(mysqli_query($conexao, $sql)):
		$_SESSION['mensagem'] = "Deletado com sucesso!";
		header('Location: adicionar.php');
	else:
		$_SESSION['mensagem'] = "Erro ao deletar";
		header('Location: adicionar.php');
	endif;
endif;