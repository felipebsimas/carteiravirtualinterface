<?php
// Sessão
session_start();
// Conexão
require_once 'conexao.php';

if(isset($_POST['btn-deletar'])):


	
	$sql = "DELETE FROM gastos";
	

	if(mysqli_query($conexao, $sql)):
		$_SESSION['mensagem'] = "Deletado com sucesso!";
		header('Location: adicionar.php');
	else:
		$_SESSION['mensagem'] = "Erro ao deletar";
		header('Location: adicionar.php');
	endif;
endif;