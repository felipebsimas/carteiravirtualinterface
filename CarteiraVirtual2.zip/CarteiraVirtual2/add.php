<?php
// Sessão
session_start();
// Conexão
require_once 'conexao.php';




	

if(isset($_POST['btn-cadastrar'])):
	$nome = ($_POST['nome']);
	$valor = ($_POST['valor']);
	$data = ($_POST['data']);


	$sql = "INSERT INTO receita (nome_rec, valor_receita,data_receita) VALUES ('$nome', '$valor','$data')";

	if(mysqli_query($conexao, $sql)):
		$_SESSION['mensagem'] = "Sucesso!";
		header('Location: adicionar.php');
	else:
		$_SESSION['mensagem'] = "Erro desconhecido!";
		header('Location: adicionar.php');
	endif;
endif;
?>
