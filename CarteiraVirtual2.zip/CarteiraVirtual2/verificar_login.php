<?php
if (session_status() !== PHP_SESSION_ACTIVE)
 {
    session_start();
    }

if (!$_SESSION['nome']){
	header('Location: login.php');
	exit();
}



?>