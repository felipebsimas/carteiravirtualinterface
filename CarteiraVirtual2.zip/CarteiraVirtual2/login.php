
<?php
session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login CarteiraVirtual</title>
	<link rel="stylesheet" href="loginstyle.css">
</head>
<body>
		
		<?php
			if (isset($_SESSION['nao_autenticado'])):
		?>
		<div>
			<p>LOGIN e/ou SENHA INCORRETO!</p>
		</div>
		<?php
		endif;
		unset($_SESSION['nao_autenticado']);
		?>

		<style type="text/css">
			.box input[type="submit"]:hover{

	background: #2980b9;
	
}
		</style>

		<form class="box" action="validar.php" method="POST">
			<img id="logo" src="logo3.png">
			<input type="text" name="usuario" placeholder="Nome de Usuario">
			<input type="password" name="senha" placeholder="Senha">
			<input type="submit" name="" value="Login" style="width: 300px;">
			<p class="cadastro_button" style="background-color: #2980b9;"><a href="cadastro.php" style="text-decoration: none; color: white;">Cadastrar</a></p>
		</form>
</body>
</html>